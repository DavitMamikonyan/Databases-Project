CREATE INDEX IX_Reservation_CheckIn_CheckOut ON Reservation(check_in, check_out);
CREATE INDEX IX_Reservation_Guest ON Reservation(guest_id);
CREATE INDEX IX_Reservation_Room ON Reservation(room_id);
CREATE INDEX IX_Payment_Status ON Payment(status);
CREATE INDEX IX_Room_RoomType ON Room(room_type_id);
CREATE INDEX IX_Room_Status ON Room(status);
CREATE INDEX IX_Guest_Email ON Guest(email);
GO