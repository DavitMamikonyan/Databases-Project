import streamlit as st
import pyodbc
import pandas as pd
from datetime import date, timedelta

# --- CONFIGURATION ---
CONNECTION_CONFIG = {
    "DRIVER": "{ODBC Driver 17 for SQL Server}",
    "SERVER": r"DESKTOP-VSUOLNE\SQLEXPRESS01",
    "DATABASE": "HotelDB",
    "Trusted_Connection": "yes"
}

def get_connection() -> pyodbc.Connection:
    conn_str = ";".join([f"{k}={v}" for k, v in CONNECTION_CONFIG.items()])
    return pyodbc.connect(conn_str)

# --- DATA ACCESS LAYER ---
def fetch_data(query: str, params: tuple = ()) -> pd.DataFrame:
    with get_connection() as conn:
        return pd.read_sql(query, conn, params=params)

def execute_query(query: str, params: tuple = ()) -> any:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        result = None
        if cursor.description:
            result = cursor.fetchone()[0]
        conn.commit()
        return result

# --- PAGE RENDERING FUNCTIONS ---

def show_dashboard():
    st.title("Executive Dashboard")
    
    # Top Level Metrics
    res_count = fetch_data("SELECT COUNT(*) FROM Reservation WHERE status != 'cancelled'").iloc[0,0]
    total_rev = fetch_data("SELECT SUM(amount) FROM Payment WHERE status = 'completed'").iloc[0,0]
    
    m1, m2, m3 = st.columns(3)
    m1.metric("Active Reservations", res_count)
    m2.metric("Total Revenue", f"${total_rev:,.2f}")
    m3.metric("System Status", "Operational")

    st.divider()
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Revenue by Room Category")
        df_rev = fetch_data("SELECT type_name, total_revenue FROM RevenueByRoomType")
        st.bar_chart(df_rev.set_index('type_name'))
        
    with col2:
        st.subheader("Occupancy Trends")
        df_occ = fetch_data("SELECT month, total_nights_booked FROM MonthlyOccupancy")
        st.line_chart(df_occ.set_index('month'))

def show_booking_engine():
    st.title("Reservation Engine")
    
    with st.expander("Search Room Availability", expanded=True):
        c1, c2 = st.columns(2)
        check_in = c1.date_input("Arrival", date.today())
        check_out = c2.date_input("Departure", date.today() + timedelta(days=1))
        
        if st.button("Check Availability", use_container_width=True):
            df = fetch_data("EXEC CheckAvailability ?, ?", (check_in.isoformat(), check_out.isoformat()))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.warning("No availability found for these dates.")

    st.divider()
    st.subheader("New Booking Entry")
    with st.form("booking_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        g_id = c1.number_input("Guest ID", min_value=1, step=1)
        r_id = c2.number_input("Room ID", min_value=1, step=1)
        
        if st.form_submit_button("Finalize Reservation", use_container_width=True):
            try:
                sql = "DECLARE @rid INT; EXEC MakeReservation ?, ?, ?, ?, @rid OUTPUT; SELECT @rid;"
                new_id = execute_query(sql, (g_id, r_id, check_in.isoformat(), check_out.isoformat()))
                st.success(f"Confirmed. ID: {new_id}")
            except Exception as e:
                st.error(f"Error: {str(e).split(']')[-1]}")

def show_entity_management():
    st.title("Database Management")
    
    choice = st.radio("Select Table", ["Guests", "Rooms", "Services"], horizontal=True)
    
    if choice == "Guests":
        with st.form("add_guest"):
            st.subheader("Register Guest")
            c1, c2 = st.columns(2)
            fn = c1.text_input("First Name")
            ln = c2.text_input("Last Name")
            em = c1.text_input("Email")
            ph = c2.text_input("Phone")
            doc = st.text_input("Identification Document")
            if st.form_submit_button("Save Guest"):
                execute_query("INSERT INTO Guest (first_name, last_name, email, phone, id_document) VALUES (?,?,?,?,?)", (fn, ln, em, ph, doc))
                st.toast("Guest Saved")
        
        st.subheader("Guest Registry")
        st.dataframe(fetch_data("SELECT guest_id, first_name, last_name, email, phone FROM Guest"), use_container_width=True)

    elif choice == "Rooms":
        st.subheader("Room Inventory")
        df_rooms = fetch_data("""
            SELECT r.room_id, r.room_number, rt.type_name, r.floor, r.status 
            FROM Room r JOIN RoomType rt ON r.room_type_id = rt.room_type_id
        """)
        st.dataframe(df_rooms, use_container_width=True, hide_index=True)
        
    elif choice == "Services":
        st.subheader("Hotel Services")
        df_serv = fetch_data("SELECT * FROM Service")
        st.table(df_serv)

# --- MAIN EXECUTION ---
def main():
    st.set_page_config(page_title="Hotel Management System", layout="wide")

    # Professional Sidebar Navigation
    with st.sidebar:
        st.title("Hotel Operations")
        st.markdown("---")
        menu = st.radio(
            "Navigate to:",
            ["Dashboard", "Bookings", "Management"],
            index=0
        )
        st.markdown("---")
        st.caption("Connected to: HotelDB")

    if menu == "Dashboard":
        show_dashboard()
    elif menu == "Bookings":
        show_booking_engine()
    elif menu == "Management":
        show_entity_management()

if __name__ == "__main__":
    main()