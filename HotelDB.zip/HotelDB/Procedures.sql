CREATE PROCEDURE MakeReservation
    @guest_id INT,
    @room_id INT,
    @check_in DATE,
    @check_out DATE,
    @reservation_id INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 FROM Reservation
        WHERE room_id = @room_id
          AND status NOT IN ('cancelled')
          AND @check_in < check_out
          AND @check_out > check_in
    )
    BEGIN
        RAISERROR('Room is already booked for the selected dates', 16, 1);
        RETURN;
    END

    DECLARE @base_price DECIMAL(10,2);
    SELECT @base_price = base_price
    FROM Room r
    JOIN RoomType rt ON r.room_type_id = rt.room_type_id
    WHERE r.room_id = @room_id;

    DECLARE @nights INT = DATEDIFF(day, @check_in, @check_out);
    DECLARE @total DECIMAL(10,2) = @nights * @base_price;

    INSERT INTO Reservation (guest_id, room_id, check_in, check_out, total_price)
    VALUES (@guest_id, @room_id, @check_in, @check_out, @total);

    SET @reservation_id = SCOPE_IDENTITY();
END;
GO

CREATE PROCEDURE ProcessPayment
    @reservation_id INT,
    @amount DECIMAL(10,2),
    @method VARCHAR(20),
    @payment_id INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Payment (reservation_id, amount, method, status)
    VALUES (@reservation_id, @amount, @method, 'completed');
    SET @payment_id = SCOPE_IDENTITY();

    UPDATE Reservation SET status = 'confirmed' WHERE reservation_id = @reservation_id;
END;
GO

CREATE PROCEDURE CancelReservation
    @reservation_id INT,
    @cancellation_date DATE = NULL,
    @fee_amount DECIMAL(10,2) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF @cancellation_date IS NULL SET @cancellation_date = GETDATE();

    DECLARE @check_in DATE;
    SELECT @check_in = check_in FROM Reservation WHERE reservation_id = @reservation_id;

    SET @fee_amount = 0;
    IF @cancellation_date >= DATEADD(day, -1, @check_in)
    BEGIN

        SELECT @fee_amount = total_price * 0.5 FROM Reservation WHERE reservation_id = @reservation_id;

        INSERT INTO Payment (reservation_id, amount, method, status)
        VALUES (@reservation_id, @fee_amount, 'cancellation_fee', 'completed');
    END

    UPDATE Reservation SET status = 'cancelled' WHERE reservation_id = @reservation_id;
END;
GO

CREATE PROCEDURE CheckAvailability
    @check_in DATE,
    @check_out DATE
AS
BEGIN
    SET NOCOUNT ON;
    SELECT r.room_id, r.room_number, rt.type_name, rt.base_price
    FROM Room r
    JOIN RoomType rt ON r.room_type_id = rt.room_type_id
    WHERE r.status = 'available'
      AND NOT EXISTS (
          SELECT 1 FROM Reservation res
          WHERE res.room_id = r.room_id
            AND res.status NOT IN ('cancelled')
            AND @check_in < res.check_out
            AND @check_out > res.check_in
      );
END;
GO