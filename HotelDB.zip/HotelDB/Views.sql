-- Available rooms for today
CREATE VIEW AvailableRoomsToday AS
SELECT r.room_id, r.room_number, rt.type_name, rt.base_price, rt.capacity
FROM Room r
JOIN RoomType rt ON r.room_type_id = rt.room_type_id
WHERE r.status = 'available'
  AND NOT EXISTS (
      SELECT 1 FROM Reservation res
      WHERE res.room_id = r.room_id
        AND res.status NOT IN ('cancelled')
        AND GETDATE() BETWEEN res.check_in AND res.check_out
  );
GO

-- Monthly occupancy summary
CREATE VIEW MonthlyOccupancy AS
SELECT YEAR(check_in) AS year, MONTH(check_in) AS month,
       COUNT(reservation_id) AS total_reservations,
       SUM(DATEDIFF(day, check_in, check_out)) AS total_nights_booked,
       AVG(DATEDIFF(day, check_in, check_out)) AS avg_stay_length
FROM Reservation
WHERE status NOT IN ('cancelled')
GROUP BY YEAR(check_in), MONTH(check_in);
GO

-- Guest spending summary
CREATE VIEW GuestSpending AS
SELECT g.guest_id, g.first_name, g.last_name,
       COUNT(r.reservation_id) AS bookings,
       SUM(r.total_price) AS total_spent,
       SUM(p.amount) AS total_paid
FROM Guest g
LEFT JOIN Reservation r ON g.guest_id = r.guest_id AND r.status NOT IN ('cancelled')
LEFT JOIN Payment p ON r.reservation_id = p.reservation_id AND p.status = 'completed'
GROUP BY g.guest_id, g.first_name, g.last_name;
GO

-- Revenue by room type
CREATE VIEW RevenueByRoomType AS
SELECT rt.type_name,
       COUNT(r.reservation_id) AS total_bookings,
       SUM(r.total_price) AS total_revenue
FROM Reservation r
JOIN Room rm ON r.room_id = rm.room_id
JOIN RoomType rt ON rm.room_type_id = rt.room_type_id
WHERE r.status NOT IN ('cancelled')
GROUP BY rt.type_name;
GO