-- All rooms with their type and price
SELECT r.room_number, rt.type_name, rt.base_price, r.status
FROM Room r
JOIN RoomType rt ON r.room_type_id = rt.room_type_id;

-- All current reservations with guest names
SELECT r.reservation_id, g.first_name, g.last_name, r.check_in, r.check_out, r.total_price
FROM Reservation r
JOIN Guest g ON r.guest_id = g.guest_id
WHERE r.status NOT IN ('cancelled', 'checked_out');

-- Average nightly rate by room type
SELECT rt.type_name, AVG(r.total_price / DATEDIFF(day, r.check_in, r.check_out)) AS avg_nightly_rate
FROM Reservation r
JOIN Room rm ON r.room_id = rm.room_id
JOIN RoomType rt ON rm.room_type_id = rt.room_type_id
WHERE r.status NOT IN ('cancelled')
GROUP BY rt.type_name;