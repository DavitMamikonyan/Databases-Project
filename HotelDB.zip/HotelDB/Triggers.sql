-- Trigger 1: Prevent double-booking (instead of insert)
CREATE TRIGGER trg_CheckRoomAvailability
ON Reservation
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1
        FROM Reservation r
        INNER JOIN inserted i ON r.room_id = i.room_id
        WHERE r.status NOT IN ('cancelled')
          AND i.check_in < r.check_out
          AND i.check_out > r.check_in
    )
    BEGIN
        RAISERROR('Room is already booked for the selected dates', 16, 1);
        ROLLBACK;
        RETURN;
    END

    INSERT INTO Reservation (guest_id, room_id, check_in, check_out, total_price, status, created_at)
    SELECT guest_id, room_id, check_in, check_out, total_price, status, created_at
    FROM inserted;
END;
GO

-- Trigger 2: Update room status when reservation status changes
CREATE TRIGGER trg_UpdateRoomStatus
ON Reservation
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    -- When a reservation becomes checked_in, mark room as occupied
    UPDATE Room
    SET status = 'occupied'
    FROM Room r
    INNER JOIN inserted i ON r.room_id = i.room_id
    WHERE i.status = 'checked_in'
      AND EXISTS (SELECT 1 FROM deleted d WHERE d.reservation_id = i.reservation_id AND d.status != 'checked_in');

    -- When a reservation becomes checked_out or cancelled, mark room as available
    UPDATE Room
    SET status = 'available'
    FROM Room r
    INNER JOIN inserted i ON r.room_id = i.room_id
    WHERE i.status IN ('checked_out', 'cancelled')
      AND EXISTS (SELECT 1 FROM deleted d WHERE d.reservation_id = i.reservation_id AND d.status NOT IN ('checked_out', 'cancelled'));
END;
GO

-- Trigger 3: Prevent negative stock (not applicable for hotel, but we could prevent overbooking via the first trigger)
CREATE TRIGGER trg_UpdateReservationTotal
ON ReservationService
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    -- Recalculate total_price for affected reservations
    UPDATE r
    SET total_price = (DATEDIFF(day, r.check_in, r.check_out) * rt.base_price) + ISNULL((
        SELECT SUM(rs.quantity * rs.price_at_time)
        FROM ReservationService rs
        WHERE rs.reservation_id = r.reservation_id
    ), 0)
    FROM Reservation r
    JOIN Room rm ON r.room_id = rm.room_id
    JOIN RoomType rt ON rm.room_type_id = rt.room_type_id
    WHERE r.reservation_id IN (SELECT reservation_id FROM inserted UNION SELECT reservation_id FROM deleted);
END;
GO