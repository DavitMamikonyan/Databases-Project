-- For SQL authentication:
CREATE LOGIN app_user WITH PASSWORD = 'StrongP@ss123';
CREATE USER app_user FOR LOGIN app_user;

-- Create roles or grant directly
GRANT SELECT ON Room TO app_user;
GRANT SELECT ON RoomType TO app_user;
GRANT EXECUTE ON MakeReservation TO app_user;
GRANT EXECUTE ON CheckAvailability TO app_user;
GRANT INSERT ON Guest TO app_user;

-- Manager user (full control)
CREATE LOGIN manager WITH PASSWORD = 'Manager456';
CREATE USER manager FOR LOGIN manager;
ALTER ROLE db_owner ADD MEMBER manager;

-- Read-only reporting user
CREATE LOGIN reporter WITH PASSWORD = 'ReadOnly789';
CREATE USER reporter FOR LOGIN reporter;
GRANT SELECT ON DATABASE::HotelDB TO reporter;

GO