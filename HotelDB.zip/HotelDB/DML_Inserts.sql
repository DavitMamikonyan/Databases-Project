INSERT INTO RoomType (type_name, description, base_price, capacity)
VALUES
    ('Standard', 'Standard room with basic amenities', 80.00, 2),
    ('Deluxe', 'Larger room with city view', 120.00, 2),
    ('Suite', 'Spacious suite with living area', 200.00, 4),
    ('Family', 'Two connecting rooms for families', 180.00, 5),
    ('Penthouse', 'Top floor luxury suite', 350.00, 2);
GO

DECLARE @i INT = 1;
WHILE @i <= 50
BEGIN
    DECLARE @floor INT = ((@i - 1) / 10) + 1;
    DECLARE @room_num VARCHAR(10) = CONCAT(@floor, RIGHT('0' + CAST(((@i - 1) % 10 + 1) AS VARCHAR), 2));
    DECLARE @room_type INT = ((@i - 1) % 5) + 1;

    INSERT INTO Room (room_number, floor, room_type_id)
    VALUES (@room_num, @floor, @room_type);

    SET @i = @i + 1;
END;
GO

INSERT INTO Guest (first_name, last_name, email, phone, address, id_document) VALUES
('Aram', 'Hovhannisyan', 'aram.hov@email.com', '+37411223301', 'Bagratunyats 12, Yerevan', 'AM1234501'),
('Ani', 'Sargsyan', 'ani.sarg@email.com', '+37411223302', 'Abovyan 34, Yerevan', 'AM1234502'),
('Hayk', 'Petrosyan', 'hayk.pet@email.com', '+37411223303', 'Mashtots 56, Gyumri', 'AM1234503'),
('Lusine', 'Grigoryan', 'lusine.grig@email.com', '+37411223304', 'Sayat-Nova 78, Vanadzor', 'AM1234504'),
('Tigran', 'Khachatryan', 'tigran.kh@email.com', '+37411223305', 'Nalbandyan 90, Dilijan', 'AM1234505'),
('Nune', 'Harutyunyan', 'nune.har@email.com', '+37411223306', 'Teryan 11, Yerevan', 'AM1234506'),
('Vardan', 'Mkrtchyan', 'vardan.mkr@email.com', '+37411223307', 'Khanjyan 22, Gyumri', 'AM1234507'),
('Mariam', 'Karapetyan', 'mariam.kar@email.com', '+37411223308', 'Aram 33, Vanadzor', 'AM1234508'),
('Gevorg', 'Aslanyan', 'gevorg.asl@email.com', '+37411223309', 'Komitas 44, Yerevan', 'AM1234509'),
('Arpine', 'Melkonyan', 'arpine.mel@email.com', '+37411223310', 'Pushkin 55, Ashtarak', 'AM1234510'),
('Sargis', 'Vardanyan', 'sargis.var@email.com', '+37411223311', 'Isahakyan 66, Yerevan', 'AM1234511'),
('Lilit', 'Avetisyan', 'lilit.ave@email.com', '+37411223312', 'Paronyan 77, Gyumri', 'AM1234512'),
('Artur', 'Gasparyan', 'artur.gas@email.com', '+37411223313', 'Shirak 88, Vanadzor', 'AM1234513'),
('Ruzanna', 'Margaryan', 'ruzanna.mar@email.com', '+37411223314', 'Byuzand 99, Yerevan', 'AM1234514'),
('Edgar', 'Hakobyan', 'edgar.hak@email.com', '+37411223315', 'Saryan 101, Dilijan', 'AM1234515'),
('Tatev', 'Galstyan', 'tatev.gal@email.com', '+37411223316', 'Charents 112, Yerevan', 'AM1234516'),
('Arman', 'Danielyan', 'arman.dan@email.com', '+37411223317', 'Tumanyan 123, Gyumri', 'AM1234517'),
('Gohar', 'Yeghiazaryan', 'gohar.yegh@email.com', '+37411223318', 'Leningradyan 134, Vanadzor', 'AM1234518'),
('Karen', 'Manukyan', 'karen.man@email.com', '+37411223319', 'Moscowyan 145, Yerevan', 'AM1234519'),
('Anna', 'Barseghyan', 'anna.bar@email.com', '+37411223320', 'Kievyan 156, Ashtarak', 'AM1234520'),
('Vahan', 'Ghazaryan', 'vahan.gha@email.com', '+37411223321', 'Hrazdan 167, Yerevan', 'AM1234521'),
('Syuzanna', 'Poghosyan', 'syuzanna.pog@email.com', '+37411223322', 'Sebastia 178, Gyumri', 'AM1234522'),
('Rafael', 'Simonyan', 'rafael.sim@email.com', '+37411223323', 'Artsakh 189, Vanadzor', 'AM1234523'),
('Narek', 'Mkhitaryan', 'narek.mkh@email.com', '+37411223324', 'Andranik 200, Yerevan', 'AM1234524'),
('Liana', 'Badalyan', 'liana.bad@email.com', '+37411223325', 'Zakyan 211, Dilijan', 'AM1234525'),
('Ashot', 'Minasyan', 'ashot.min@email.com', '+37411223326', 'Tigran Mets 222, Yerevan', 'AM1234526'),
('Nina', 'Stepanyan', 'nina.ste@email.com', '+37411223327', 'Grigor Lusavorich 233, Gyumri', 'AM1234527'),
('Hovhannes', 'Babayan', 'hovhannes.bab@email.com', '+37411223328', 'Eznik Koghbatsi 244, Vanadzor', 'AM1234528'),
('Meline', 'Dallakyan', 'meline.dal@email.com', '+37411223329', 'Mher Mkrtchyan 255, Yerevan', 'AM1234529'),
('Arsen', 'Ohanyan', 'arsen.oha@email.com', '+37411223330', 'Paruyr Sevak 266, Ashtarak', 'AM1234530'),
('Kristine', 'Shahbazyan', 'kristine.sha@email.com', '+37411223331', 'Avetik Isahakyan 277, Yerevan', 'AM1234531'),
('Gagik', 'Terteryan', 'gagik.ter@email.com', '+37411223332', 'William Saroyan 288, Gyumri', 'AM1234532'),
('Armine', 'Mikaelyan', 'armine.mik@email.com', '+37411223333', 'Khachatur Abovyan 299, Yerevan', 'AM1234533'),
('Ivan', 'Volkov', 'ivan.volkov@mail.ru', '+37411223334', 'Tverskaya 10, Moscow, Russia', 'RU1000001'),
('Olga', 'Kuznetsova', 'olga.kuz@mail.ru', '+37411223335', 'Nevsky 25, St. Petersburg, Russia', 'RU1000002'),
('Dmitry', 'Smirnov', 'dmitry.smir@yandex.ru', '+37411223336', 'Lenina 5, Novosibirsk, Russia', 'RU1000003'),
('Elena', 'Fedorova', 'elena.fed@gmail.com', '+37411223337', 'Pushkinskaya 15, Yekaterinburg, Russia', 'RU1000004'),
('Sergey', 'Morozov', 'sergey.mor@mail.ru', '+37411223338', 'Gagarina 8, Kazan, Russia', 'RU1000005'),
('Raj', 'Patel', 'raj.patel@indianmail.com', '+37411223339', 'Gandhi Road 42, Mumbai, India', 'IN2000001'),
('Priya', 'Sharma', 'priya.sharma@indianmail.com', '+37411223340', 'Banjara Hills 88, Hyderabad, India', 'IN2000002');
GO

DECLARE @counter INT = 1;
WHILE @counter <= 40
BEGIN
    DECLARE @guest_id INT = (SELECT TOP 1 guest_id FROM Guest ORDER BY NEWID());
    DECLARE @room_id INT = (SELECT TOP 1 room_id FROM Room ORDER BY NEWID());
    DECLARE @check_in DATE = DATEADD(day, (ABS(CHECKSUM(NEWID())) % 180), '2025-01-01');
    DECLARE @check_out DATE = DATEADD(day, (ABS(CHECKSUM(NEWID())) % 7) + 1, @check_in);
    DECLARE @nights INT = DATEDIFF(day, @check_in, @check_out);
    DECLARE @base_price DECIMAL(10,2) = (SELECT base_price FROM RoomType WHERE room_type_id = (SELECT room_type_id FROM Room WHERE room_id = @room_id));
    DECLARE @total_price DECIMAL(10,2) = @nights * @base_price;

    INSERT INTO Reservation (guest_id, room_id, check_in, check_out, total_price, status)
    VALUES (@guest_id, @room_id, @check_in, @check_out, @total_price, 'confirmed');

    SET @counter = @counter + 1;
END;
GO

INSERT INTO Payment (reservation_id, amount, method, status)
SELECT reservation_id,
       total_price,
       CASE (reservation_id % 4) WHEN 0 THEN 'cash' WHEN 1 THEN 'credit_card' WHEN 2 THEN 'debit_card' ELSE 'bank_transfer' END,
       CASE (reservation_id % 3) WHEN 0 THEN 'completed' WHEN 1 THEN 'pending' ELSE 'completed' END
FROM Reservation;
GO

INSERT INTO Service (name, price, description)
VALUES
    ('Breakfast Buffet', 15.00, 'Daily breakfast buffet'),
    ('Spa Treatment', 80.00, '60-minute relaxing massage'),
    ('Airport Shuttle', 25.00, 'One-way airport transfer'),
    ('Late Check-out', 30.00, 'Check-out until 6 PM'),
    ('Extra Bed', 20.00, 'Rollaway bed per night'),
    ('Laundry Service', 15.00, 'Per item laundry'),
    ('Gym Access', 10.00, 'Daily access to fitness center'),
    ('Swimming Pool', 0.00, 'Free for guests'),
    ('Room Service', 5.00, 'Delivery fee per order'),
    ('City Tour', 50.00, 'Guided city tour');
GO

INSERT INTO ReservationService (reservation_id, service_id, quantity, price_at_time)
SELECT r.reservation_id, s.service_id, (ABS(CHECKSUM(NEWID())) % 3) + 1, s.price
FROM Reservation r
CROSS JOIN Service s
WHERE r.reservation_id % 5 = 0
  AND s.service_id BETWEEN 1 AND 5;
GO